import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(express.json());

app.post("/drop", async (req, res) => {
  const prompt = req.body?.prompt || "🌇 Daily Prompt: Futuristic sunset over cyber-KL skyline";

  const token = process.env.DROP_BOT_TOKEN;
  const chatId = process.env.DROP_CHANNEL_ID;

  const telegramURL = `https://api.telegram.org/bot${token}/sendMessage`;

  const payload = {
    chat_id: chatId,
    text: `🖼️ *Daily Prompt Drop*\n\n${prompt}`,
    parse_mode: "Markdown"
  };

  const tg = await fetch(telegramURL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const result = await tg.json();
  return res.status(200).json({ sent: result.ok });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("✅ DropBot is live on port", PORT));
